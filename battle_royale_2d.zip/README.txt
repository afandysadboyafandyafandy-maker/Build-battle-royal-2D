BATTLE ROYALE 2D - versi awal

Isi ZIP:
- index.html: game battle royale 2D offline melawan bot.

Cara mencoba:
1. Ekstrak ZIP.
2. Buka index.html di browser untuk mencoba.
3. Untuk GitHub Pages, unggah index.html ke root repository dan aktifkan Settings > Pages > Branch main > /(root).

Catatan:
Versi ini belum memiliki multiplayer online dan belum berupa APK. Multiplayer membutuhkan server; APK memerlukan proses build terpisah.
